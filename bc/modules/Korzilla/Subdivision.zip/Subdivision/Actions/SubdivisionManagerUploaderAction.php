<?php

namespace App\modules\Korzilla\Subdivision\Actions;
use App\modules\Korzilla\Subdivision\Data\Repositories\SubClassRepository;
use App\modules\Korzilla\Subdivision\Data\Repositories\SubdivisionRepository;
use App\modules\Korzilla\Subdivision\Models\SubClassModel;
use App\modules\Korzilla\Subdivision\Models\SubdivisionModel;
use App\modules\Korzilla\Subdivision\Tasks\SubdivisionGetAllTask;
use App\modules\Korzilla\Subdivision\Tasks\SubdivisionGetRootTask;
use App\modules\Korzilla\Subdivision\Tasks\SubdivisionSortTask;
use App\modules\Korzilla\Subdivision\Values\DTO\SubdivisionDataDTO;
use App\modules\Korzilla\Subdivision\Values\Inputs\SubdivisionSetInput;
use App\modules\Korzilla\Subdivision\Values\Outputs\SubdivisionSetOutput;
use Exception;

class SubdivisionManagerUploaderAction
{


    /** @var \nc_Db*/
    private $db;

    /** @var int*/
    private $catalogueId;


    /** @var \nc_Core*/
    private $core;

    /**
    *  Раздел куда будет выгружаться новые разделы 
    *  @var SubdivisionDataDTO */
    private $rootSubdivision;

    /** @var SubdivisionModel[] */
    private $allSubdivision = [];

    /** @var SubdivisionSetOutput[] */
    private $subdivisionSetOutput = [];


    //*Репозитории
    /** @var SubdivisionRepository  */
    private $subdivisionRepository ;

    /** @var SubClassRepository  */
    private $subClassRepository ;

    //*Задачи
    /** @var SubdivisionGetAllTask  */
    private $subdivisionGetAllTask ;

    /** @var SubdivisionGetRootTask  */
    private $subdivisionGetRootTask ;

    /** @var SubdivisionSortTask  */
    private $subdivisionSortTask ;

    function __construct(\nc_Core $core)
    {
        $this->core = $core;
        $this->db = $core->db;
        $this->catalogueId = $core->catalogue->get_by_host_name(str_replace("www.", "", $_SERVER['HTTP_HOST']))['Catalogue_ID'];



        //*Репозитории
        $this->subdivisionRepository =  new SubdivisionRepository($this->db);
        $this->subClassRepository =new SubClassRepository($this->db);


        //*Задачи
        $this->subdivisionGetAllTask =  new SubdivisionGetAllTask($this->subdivisionRepository);
        $this->subdivisionGetRootTask = new SubdivisionGetRootTask($this->subdivisionRepository, $this->subClassRepository);
        $this->subdivisionSortTask = new SubdivisionSortTask();
    
    }

    /**
     * Undocumented function
     *
     * @param SubdivisionSetInput[] $input -- массив разделов которые будут выгружаться
     * @param int|null $subdivisionId -- ID раздела куда будут выгружаться разделы
     * @return SubdivisionSetInput[]
     */
    public function run(array $input, int $subdivisionId = null)
    {   

        $this->allSubdivision = $this->subdivisionGetAllTask->run($this->catalogueId);

        $this->rootSubdivision = $this->subdivisionGetRootTask->run($this->catalogueId, $subdivisionId);

        $sortedSubdivisionSetInputs = $this->subdivisionSortTask->run($input);
        


        foreach ($sortedSubdivisionSetInputs as $key => $subdivisionSetInput) {

            /** @var SubdivisionDataDTO $parentSubdivision */
            $parentSubdivision;
            if(isset($this->subdivisionSetOutput[$subdivisionSetInput->parentId])){
                $parentSubdivision = $this->subdivisionSetOutput[$subdivisionSetInput->parentId];
            }
            else{
                $parentSubdivision = $this->rootSubdivision;

            }

            $priority = $this->db->get_var("SELECT SQL_NO_CACHE MAX(Priority) FROM Subdivision WHERE Catalogue_ID = '{$this->catalogueId}' AND  Parent_Sub_ID = '{$parentSubdivision->Subdivision_ID}'") + 1;
            $englishName = encodestring($subdivisionSetInput->Subdivision_Name, 1);
            $hiddenUrl = $parentSubdivision->Hidden_URL . $englishName . "/";

            // var_dump($this->allSubdivision);
            // exit;
            if (isset($this->allSubdivision[$subdivisionSetInput->id])) {
                //*UPDATE
                echo "<br>UPDATE<br>";
                $updateModel = $this->allSubdivision[$subdivisionSetInput->id];

                $updateModel->Parent_Sub_ID= $parentSubdivision->Subdivision_ID;
                $updateModel->Subdivision_Name = $subdivisionSetInput->Subdivision_Name;
                $updateModel->EnglishName = $englishName;
                $updateModel->Hidden_URL= $hiddenUrl;
                $updateModel->Checked = $subdivisionSetInput->Checked;
                $updateModel->Priority= $priority;

                if(!$this->subdivisionRepository->save($updateModel)){
                    throw new Exception($this->db->last_error, 1);                
                };

                $this->subdivisionSetOutput[$subdivisionSetInput->id] = SubdivisionDataDTO::fromModel($updateModel);

            }else{

                echo "<br>CREATE<br>";
                $newSubdivisionModel = new SubdivisionModel();

                $newSubdivisionModel->Catalogue_ID= $this->catalogueId;
                $newSubdivisionModel->Parent_Sub_ID= $parentSubdivision->Subdivision_ID;
                $newSubdivisionModel->Subdivision_Name= addslashes($subdivisionSetInput->Subdivision_Name);
                $newSubdivisionModel->Priority= $priority;
                $newSubdivisionModel->Checked= $subdivisionSetInput->Checked;
                $newSubdivisionModel->EnglishName= $englishName;
                $newSubdivisionModel->Hidden_URL= $hiddenUrl;
                $newSubdivisionModel->Catalogue_ID= $this->catalogueId;

                $newSubdivisionModel->code1C= $subdivisionSetInput->id;
                $newSubdivisionModel->subdir= 1;
    
                if(!$this->subdivisionRepository->save($newSubdivisionModel)){
                    throw new Exception($this->db->last_error, 1);   
                };
    
                $newSubClass = new SubClassModel();
                $newSubClass->Subdivision_ID = $newSubdivisionModel->Subdivision_ID;
                $newSubClass->Class_ID = 2001;
                $newSubClass->Sub_Class_Name = $englishName;
                $newSubClass->EnglishName = $englishName;
                $newSubClass->Checked = 1;
                $newSubClass->Class_Template_ID = 0;
                $newSubClass->Catalogue_ID = $this->catalogueId;
    
                if(!$this->subClassRepository->save($newSubClass)){
                    throw new Exception($this->db->last_error, 1);                
                };

                $this->subdivisionSetOutput[$subdivisionSetInput->id] = SubdivisionDataDTO::fromModel($newSubdivisionModel,$newSubClass->Sub_Class_ID);
            }









        }

        return $this->subdivisionSetOutput;

    }


    public function create(){
        
    }




    // private function addSubdivision(SubdivisionDTO $data, NewSubdivisionDTO $parentSubdivision)
    // {
    //     $newSubdivision = new NewSubdivisionDTO();
    //     $this->addSubdivisionToDB($data, $parentSubdivision, $newSubdivision);
    //     $this->addSubClassToDB($data, $newSubdivision);
    //     $this->newSubdivision[$data->id] = $newSubdivision;
    // }

    // /**
    //  * Undocumented function
    //  *
    //  * @param SubdivisionDTO $data
    //  * @param NewSubdivisionDTO $parentSubdivision
    //  * @return void
    //  */
    // private function addSubdivisionToDB(SubdivisionDTO $data, NewSubdivisionDTO $parentSubdivision, NewSubdivisionDTO $newSubdivision)
    // {
    //     $priority = $this->db->get_var("SELECT SQL_NO_CACHE MAX(Priority) FROM Subdivision WHERE Catalogue_ID = '{$this->catalogueId}' AND  Parent_Sub_ID = '{$parentSubdivision->subdivisionId}'") + 1;
    //     $checked = 1;
    //     $englishName = encodestring($data->name, 1);
    //     $HiddenUrl = $parentSubdivision->hiddenUrl . $englishName . "/";
    //     $SubdivisionName = addslashes($data->name);
    //     $showSubdivision = 1;

    //     // добавим раздел
    //     $res = $this->db->query(
    //         "INSERT INTO Subdivision
    //             (
    //                 Catalogue_ID,
    //                 Parent_Sub_ID,
    //                 Subdivision_Name,
    //                 Priority,
    //                 Checked,
    //                 EnglishName,
    //                 Hidden_URL,
    //                 code1C,
    //                 subdir
    //             ) 
    //         VALUES
    //             (
    //                 {$this->catalogueId},
    //                 {$parentSubdivision->subdivisionId},
    //                 '{$SubdivisionName}',
    //                 {$priority},
    //                 {$checked},
    //                 '{$englishName}',
    //                 '{$HiddenUrl}',
    //                 '{$data->id}',
    //                 '{$showSubdivision}'
    //             )"
    //     );
    //     if ($res == 0) {
    //         throw new Exception($this->db->last_error, 1);
    //     }

    //     $newSubdivision->subdivisionId = $this->db->insert_id;
    //     $newSubdivision->hiddenUrl = $HiddenUrl;
    // }

    // /**
    //  * Undocumented function
    //  *
    //  * @param SubdivisionDTO $data
    //  * @param NewSubdivisionDTO $newSubdivisionId
    //  * @return void
    //  */
    // private function addSubClassToDB(SubdivisionDTO $data, NewSubdivisionDTO $newSubdivision)
    // {

    //     $englishName = encodestring($data->name, 1);
    //     $checked = 1;

    //     // добавим инфоблок в раздел
    //     $res = $this->db->query(
    //         "INSERT INTO Sub_Class 
    //     (
    //         Subdivision_ID,
    //         Class_ID,
    //         Sub_Class_Name,
    //         EnglishName,
    //         Checked,
    //         Class_Template_ID,
    //         Catalogue_ID,
    //         DefaultAction,
    //         AllowTags,
    //         NL2BR,
    //         UseCaptcha,
    //         CacheForUser
    //     ) 
    //     VALUES
    //     (
    //         {$newSubdivision->subdivisionId},
    //         2001,
    //         '{$englishName}',
    //         '{$englishName}',   
    //         {$checked},
    //         0,
    //         {$this->catalogueId},
    //         'index',
    //         '-1',
    //         '-1',
    //         '-1',
    //         '-1'
    //     )"
    //     );
    //     if ($res == 0) {
    //         throw new Exception($this->db->last_error, 1);
    //     }

    //     $newSubdivision->subClassId = $this->db->insert_id;
    // }


    // private function updateSubdivision(SubdivisionDTO $newSubdivision , ExistingSubdivisionDTO $oldSubdivision,NewSubdivisionDTO $parentSubdivision)
    // {   

        
    //     $newHiddenUrl = $parentSubdivision->hiddenUrl . encodestring($newSubdivision->name, 1) . "/";

    //     // if ($newHiddenUrl!= $oldSubdivision->hiddenUrl) {

    //     // if (!isset($this->allSiteSubdivision[$data->parentId]) || $this->allSiteSubdivision[$data->parentId]->subdivisionId != $siteSubdivision->parentSubId) {


    //     // }
    //     return;

    //     // $newSubdivision = new NewSubdivisionDTO();
    //     // $newSubdivision->subdivisionId = $siteSubdivision->subdivisionId;
    //     // $newSubdivision->subClassId = $siteSubdivision->;
    //     // $newSubdivision->hiddenUrl = $siteSubdivision['Hidden_URL'];
    //     // $this->existingSubdivision[$data->id] = $newSubdivision;
    // }


    // public function getNewSubdivision()
    // {
    //     return $this->newSubdivision;
    // }


}





