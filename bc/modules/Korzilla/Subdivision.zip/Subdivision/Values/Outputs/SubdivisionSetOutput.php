<?php

namespace App\modules\Korzilla\Subdivision\Values\Outputs;

class SubdivisionSetOutput
{   
    /** @var int*/
    public $subdivisionId;

    /** @var int*/
    public $subClassId;

    /** @var string*/
    public $hiddenUrl;
}
