<?php


namespace App\modules\Korzilla\Subdivision\Providers;
use App\modules\Korzilla\Subdivision\Actions\SubdivisionManagerUploaderAction;
use App\modules\Korzilla\Subdivision\Values\Inputs\SubdivisionSetInput;
use App\modules\Ship\Parent\Providers\Provider;



class SubdivisionProvider extends Provider{

    private $setting;
    private $nc_core;

    public function __construct(\nc_Core $nc_core, array $setting){
        $this->setting = $setting;
        $this->nc_core = $nc_core;
    }

    /**
     * Undocumented function
     *
     * @param SubdivisionSetInput[] $input -- массив разделов которые будут выгружаться
     * @param integer|null $subdivisionId -- ID раздела куда будут выгружаться разделы
     * @return SubdivisionSetInput[]
     */
    public function upload(array $input, int $subdivisionId = null)
    {  
        $managerUploaderAction = new SubdivisionManagerUploaderAction($this->nc_core);
        return $managerUploaderAction->run($input,$subdivisionId);
    }
}