<?php

namespace App\modules\Ship\Helpers;

class FieldNotSet
{
    const CONSTANT = NAN;

}
