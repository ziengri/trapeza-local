<?php

namespace App\modules\Ship\Parent\Models;

abstract class Model{

}