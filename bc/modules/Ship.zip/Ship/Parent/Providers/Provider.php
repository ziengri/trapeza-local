<?php


namespace App\modules\Ship\Parent\Providers;



abstract class Provider{

    
}