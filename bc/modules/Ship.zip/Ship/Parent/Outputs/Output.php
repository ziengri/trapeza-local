<?php

namespace App\modules\Ship\Parent\Outputs;

class Output
{

}
