<?php

namespace App\modules\Ship\Parent\Tasks;


abstract class Task
{


}