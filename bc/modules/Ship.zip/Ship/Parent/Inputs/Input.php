<?php

namespace App\modules\Ship\Parent\Inputs;

class Input
{

}
